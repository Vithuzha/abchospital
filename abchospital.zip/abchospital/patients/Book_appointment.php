<?php
session_start();
include('../includes/db_connect.php');

// Check if the session has the user_id
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Retrieve the user_id from the session
$user_id = $_SESSION['user_id'];

// Get the Patient_ID using the User_ID from the credentials table
$sql_get_patient_id = "SELECT Patient_ID FROM credentials WHERE User_ID = ? AND Patient_ID IS NOT NULL";
$stmt_get_patient_id = $conn->prepare($sql_get_patient_id);
$stmt_get_patient_id->bind_param("i", $user_id);
$stmt_get_patient_id->execute();
$result_get_patient_id = $stmt_get_patient_id->get_result();

// Check if the query was successful and patient_id exists
if ($result_get_patient_id->num_rows == 0) {
    echo "Error: Patient not found for this user.";
    exit();
}

// Fetch the Patient_ID
$row = $result_get_patient_id->fetch_assoc();
$patient_id = $row['Patient_ID'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize the form inputs
    $doctor_id = intval($_POST['doctor_id']);
    $appointment_date = $_POST['appointment_date'];
    $reason = htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8');

    // Insert the appointment data into the appointments table
    $sql = "INSERT INTO appointments (Patient_ID, Appointment_Date, Reason, status, Doctor_ID)
            VALUES (?, ?, ?, 'Pending', ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $patient_id, $appointment_date, $reason, $doctor_id);

    if ($stmt->execute()) {
        echo "Appointment booked successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}

// Fetch doctors to populate dropdown
$sql = "SELECT Doctor_ID, Doctor_Name FROM doctor";
$result = $conn->query($sql);

// Check if there are results
if (!$result) {
    die("Database query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - ABC Virtual Hospital</title>
</head>
<style>
        body {
            background-image: url('../img/img7.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            

        }
</style
<body>
    <h1>Book an Appointment</h1>

    <form method="post" action="">
        <label for="doctor">Select Doctor:</label>
        <select name="doctor_id" required>
            <option value="">-- Select a Doctor --</option>
            <?php
            // Populate the doctor dropdown dynamically
            while ($doctor = $result->fetch_assoc()) {
                echo '<option value="' . htmlspecialchars($doctor['Doctor_ID']) . '">'
                     . htmlspecialchars($doctor['Doctor_Name']) . '</option>';
            }
            ?>
        </select><br><br>

        <label for="appointment_date">Appointment Date:</label>
        <input type="datetime-local" name="appointment_date" required><br><br>

        <label for="reason">Reason:</label>
        <textarea name="reason" required></textarea><br><br>

        <input type="submit" value="Book Appointment">
    </form>

    <a href="patient_dashboard.php">Back to Dashboard</a>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
