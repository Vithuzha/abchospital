<?php
session_start();
include('../includes/db_connect.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $appointment_id = $_POST['appointment_id'];
    $status = $_POST['status'];

    // Update the appointment status in the database
    $sql = "UPDATE appointments SET status = ? WHERE Appointment_ID = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $status, $appointment_id);

    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Status updated successfully!";
    } else {
        $error_message = "Error updating status. Please try again.";
    }

    mysqli_stmt_close($stmt);
    header("Location: view_appointments.php"); // Redirect back to the appointments page
    exit();
}
?>
