<?php
include('../includes/db_connect.php');

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert into Patient table
    $sql_patient = "INSERT INTO Patient (Patient_Name, Patient_Email, Contact_Info) VALUES ('$name', '$email', '$contact')";
    if (mysqli_query($conn, $sql_patient)) {
        $patient_id = mysqli_insert_id($conn); // Get the newly created Patient_ID

        // Insert into Credentials table
        $sql_credentials = "INSERT INTO Credentials (Username, Password, Role, Patient_ID) VALUES ('$username', '$hashed_password', 'Patient', $patient_id)";
        if (mysqli_query($conn, $sql_credentials)) {
            echo "Registration successful!";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration - ABC Virtual Hospital</title>

    <style>
        body {
            background-image: url('../img/img12.jpg');
            background-size: cover;
            background-repeat:no-repeat;
            background-attachment: fixed;

        }
    </style>
</head>
<body>
    <h1>Patient Registration</h1>
    
    <form method="post" action="register.php">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="contact">Contact Info:</label>
        <input type="text" name="contact" required><br>

        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="register" value="Register">
    </form>
</body>
</html>
