<?php
session_start();
include('../includes/db_connect.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get the User_ID of the logged-in user
$user_id = $_SESSION['user_id'];

// Get the Patient_ID from the credentials table based on the logged-in user's User_ID
$sql_patient = "SELECT Patient_ID FROM credentials WHERE User_ID = ? AND Role = 'Patient'";
$stmt_patient = mysqli_prepare($conn, $sql_patient);
mysqli_stmt_bind_param($stmt_patient, "i", $user_id);
mysqli_stmt_execute($stmt_patient);
$result_patient = mysqli_stmt_get_result($stmt_patient);

if ($result_patient && mysqli_num_rows($result_patient) > 0) {
    $patient_data = mysqli_fetch_assoc($result_patient);
    $patient_id = $patient_data['Patient_ID'];
} else {
    // Handle the case where no patient is found
    echo "Patient not found.";
    exit();
}

// Query to get appointments for the logged-in patient
$sql_appointments = "SELECT a.Appointment_ID, a.Appointment_Date, a.Reason, a.status, d.Doctor_Name 
                     FROM appointments a 
                     JOIN doctor d ON a.Doctor_ID = d.Doctor_ID 
                     WHERE a.Patient_ID = ?";
$stmt_appointments = mysqli_prepare($conn, $sql_appointments);
mysqli_stmt_bind_param($stmt_appointments, "i", $patient_id);
mysqli_stmt_execute($stmt_appointments);
$result_appointments = mysqli_stmt_get_result($stmt_appointments);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments - ABC Virtual Hospital</title>
    <style>
        body {
            background-image: url('../img/img15.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            

        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Your Appointments</h1>

    <?php if (mysqli_num_rows($result_appointments) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Appointment Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Doctor Name</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($appointment = mysqli_fetch_assoc($result_appointments)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($appointment['Appointment_ID']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['Appointment_Date']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['Reason']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['status']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['Doctor_Name']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no appointments scheduled.</p>
    <?php endif; ?>

    <a href="patient_dashboard.php">Back to Dashboard</a>
</body>
</html>

<?php
mysqli_stmt_close($stmt_patient);
mysqli_stmt_close($stmt_appointments);
mysqli_close($conn);
?>
