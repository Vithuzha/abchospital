<?php
session_start();
include('../includes/db_connect.php');

// Ensure the user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: ../login.php");
    exit();
}

// Fetch patient's details from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT p.Patient_Name, p.Contact_Info
        FROM patient p
        JOIN credentials c ON p.Patient_ID = c.Patient_ID
        WHERE c.User_ID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$patient_data = mysqli_fetch_assoc($result);

// Close statement
mysqli_stmt_close($stmt);

if (!$patient_data) {
    die("Patient not found.");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css"> <!-- Optional CSS -->
    <link rel="stylesheet" href="../styles/.">

    <style>
        body {
            background-image: url('../img/img9.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            

        }

        a {
            padding-left:  20px;
            padding-right: 20px;
            padding-bottom: 10px;
            margin: 10px;
            background-color: black;
            color: antiquewhite;
            margin: 1rem;
            text-decoration: none
        }
        li {
            margin: 2rem;
            text-decoration: none;
        }

        
    </style>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($patient_data['Patient_Name']); ?></h1>
    <p><strong>Contact Information:</strong> <?php echo htmlspecialchars($patient_data['Contact_Info']); ?></p>

    <h2>Actions</h2>
    <ul>
        <li><a href="Book_appointment.php">Book Appointments</a></li>
        <li><a href="view_appointments.php">View Appointments</a></li>
        <!-- <li><a href="access_medical_records.php">Access Medical Records</a></li> -->

        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</body>
</html>
