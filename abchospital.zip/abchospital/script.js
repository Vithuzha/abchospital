document.addEventListener("DOMContentLoaded", () => {
    console.log("About Us page loaded successfully!");
});
