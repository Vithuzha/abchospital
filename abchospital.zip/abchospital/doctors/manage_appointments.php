<?php
session_start();
include('../includes/db_connect.php');

// Check if the session has the user_id
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Retrieve the user_id from the session
$user_id = intval($_SESSION['user_id']);

// Fetch the Doctor_ID from the credentials table based on the user_id
$sql_get_doctor_id = "SELECT Doctor_ID FROM credentials WHERE User_ID = ?";
$stmt_get_doctor_id = $conn->prepare($sql_get_doctor_id);
$stmt_get_doctor_id->bind_param("i", $user_id);
$stmt_get_doctor_id->execute();
$result_doctor_id = $stmt_get_doctor_id->get_result();

if ($result_doctor_id->num_rows == 0) {
    echo "Error: Doctor not found!";
    exit();
}

$row = $result_doctor_id->fetch_assoc();
$doctor_id = $row['Doctor_ID'];

// Fetch appointments assigned to the logged-in doctor
$sql_fetch_appointments = "SELECT a.Appointment_ID, p.Patient_Name, a.Appointment_Date, a.Reason, a.status 
                           FROM appointments a 
                           INNER JOIN patient p ON a.Patient_ID = p.Patient_ID
                           WHERE a.Doctor_ID = ?";
$stmt_fetch = $conn->prepare($sql_fetch_appointments);
$stmt_fetch->bind_param("i", $doctor_id);
$stmt_fetch->execute();
$result_appointments = $stmt_fetch->get_result();

// Check if the form is submitted for updating appointments
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $appointment_id = intval($_POST['appointment_id']);
    $appointment_date = $_POST['appointment_date'];
    $reason = htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8');
    $status = $_POST['status'];

    // Update the appointment details in the database
    $sql_update_appointment = "UPDATE appointments 
                               SET Appointment_Date = ?, Reason = ?, status = ?
                               WHERE Appointment_ID = ? AND Doctor_ID = ?";
    $stmt_update = $conn->prepare($sql_update_appointment);
    $stmt_update->bind_param("sssii", $appointment_date, $reason, $status, $appointment_id, $doctor_id);

    if ($stmt_update->execute()) {
        echo "Appointment updated successfully!";
        // Reload the page to reflect changes
        header("Location: manage_appointments.php");
        exit();
    } else {
        echo "Error: " . $stmt_update->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments - ABC Virtual Hospital</title>
</head>
<body>
    <h1>Manage Appointments</h1>

    <?php if ($result_appointments->num_rows > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Patient Name</th>
                    <th>Appointment Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($appointment = $result_appointments->fetch_assoc()): ?>
                    <tr>
                        <form method="post" action="">
                            <td>
                                <?php echo htmlspecialchars($appointment['Appointment_ID']); ?>
                                <input type="hidden" name="appointment_id" value="<?php echo htmlspecialchars($appointment['Appointment_ID']); ?>">
                            </td>
                            <td><?php echo htmlspecialchars($appointment['Patient_Name']); ?></td>
                            <td>
                                <input type="datetime-local" name="appointment_date" value="<?php echo date('Y-m-d\TH:i', strtotime($appointment['Appointment_Date'])); ?>" required>
                            </td>
                            <td>
                                <textarea name="reason" required><?php echo htmlspecialchars($appointment['Reason']); ?></textarea>
                            </td>
                            <td>
                                <select name="status" required>
                                    <option value="Pending" <?php echo $appointment['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Completed" <?php echo $appointment['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Canceled" <?php echo $appointment['status'] === 'Canceled' ? 'selected' : ''; ?>>Canceled</option>
                                </select>
                            </td>
                            <td>
                                <input type="submit" value="Update">
                            </td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No appointments found for you.</p>
    <?php endif; ?>

    <a href="doctor_dashboard.php">Back to Dashboard</a>
</body>
</html>

<?php
$conn->close();
?>
