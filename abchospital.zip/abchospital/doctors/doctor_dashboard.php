<?php
session_start();
include('../includes/db_connect.php');

// Ensure the user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Doctor') {
    header("Location: ../login.php");
    exit();
}

// Fetch doctor's details from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT d.Doctor_Name, d.Specialty, d.Contact_Info
        FROM doctor d
        JOIN credentials c ON d.Doctor_ID = c.Doctor_ID
        WHERE c.User_ID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$doctor_data = mysqli_fetch_assoc($result);

// Close statement
mysqli_stmt_close($stmt);

if (!$doctor_data) {
    die("Doctor not found.");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - ABC Virtual Hospital</title>


    <style>
        body {
            background-image: url('../img/img3.png');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            height: 100vh;
          
            /* Full viewport height */
            
            /* Remove default margin */
            display: flex;
            flex-direction: column;

        }

        .action_box>a {
        
            color: white;
            text-decoration: none;
            padding: 5px 10px;
            width: 100px;
            text-align: center;
            margin: 1cap;
            background-color: rgb(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            border-radius: 10px;
            margin-left: 3cap;
            margin-right: 3cap;
        }

        .action_box {
            margin: 10px;
            display: flex;
            text-align: center;
        }
        h1 {
            left: 0;
            top: 0;
            text-align: left;
        }

    </style>

</head>

<body>

    <h1>Welcome, <?php echo htmlspecialchars($doctor_data['Doctor_Name']); ?></h1>
    <ul>
    <li><p><strong>Specialty:</strong> <?php echo htmlspecialchars($doctor_data['Specialty']); ?></p></li>
  
    <li><p><strong>Contact Information:</strong> <?php echo htmlspecialchars($doctor_data['Contact_Info']); ?></p></li>
    </ul>
    <h2>Actions</h2>
    <div class="action_box">
    <a href="manage_appointments.php">Manage Appointments</a>
    <a href="../auth/logout.php">Logout</a>
    </div>
</body>
</html>
