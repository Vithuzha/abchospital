<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

if (isset($_POST['register'])) {
    $doctor_name = $_POST['doctor_name'];
    $specialty = $_POST['specialty'];
    $contact_info = $_POST['contact_info'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashing the password
    $admin_id = $_SESSION['user_id']; // Assuming you store the user_id in session

    // Insert the new doctor into the database
    $sql_doctor = "INSERT INTO Doctor (Doctor_Name, Specialty, Contact_Info, Admin_ID)
                   VALUES ('$doctor_name', '$specialty', '$contact_info', $admin_id)";

    if (mysqli_query($conn, $sql_doctor)) {
        // Get the ID of the newly inserted doctor
        $doctor_id = mysqli_insert_id($conn);

        // Now insert the credentials for the doctor
        $sql_credentials = "INSERT INTO Credentials (Username, Password, Role, Doctor_ID)
                            VALUES ('$username', '$password', 'Doctor', $doctor_id)";

        if (mysqli_query($conn, $sql_credentials)) {
            $success = "Doctor and credentials registered successfully!";
        } else {
            $error = "Error registering credentials: " . mysqli_error($conn);
        }
    } else {
        $error = "Error registering doctor: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Doctor - ABC Virtual Hospital</title>
</head>

<body>
    <h1>Register Doctor</h1>
    
    <?php if (isset($success)) { echo "<p>$success</p>"; } ?>
    <?php if (isset($error)) { echo "<p>$error</p>"; } ?>

    <form method="post" action="register.php">
        <label for="doctor_name">Doctor Name:</label>
        <input type="text" id="doctor_name" name="doctor_name" placeholder="Enter doctor's name" required><br>

        <label for="specialty">Specialty:</label>
        <input type="text" id="specialty" name="specialty" placeholder="Enter specialty (e.g., Cardiology)"><br>

        <label for="contact_info">Contact Info:</label>
        <input type="text" id="contact_info" name="contact_info" placeholder="Enter contact information (e.g., email, phone)" required><br>

        <label for="username">Username:</label>
        <input type="text" id="username" name="username" placeholder="Enter username" required><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter password" required><br>

        <input type="submit" name="register" value="Register Doctor">
    </form>

    <br>
    <a href="../auth/admin_dashboard.php">Back to Admin Dashboard</a>
</body>
</html>
