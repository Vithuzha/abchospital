<?php
session_start();
include('../includes/db_connect.php');

if (isset($_POST['add_receptionist'])) {
    $receptionist_name = $_POST['receptionist_name'];
    $contact_info = $_POST['contact_info'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate input
    if (empty($receptionist_name) || empty($contact_info) || empty($username) || empty($password)) {
        $error = "All fields are required.";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new receptionist into the database
        $sql_receptionist = "INSERT INTO receptionist (Receptionist_Name, Contact_Info) VALUES (?, ?)";
        $stmt_receptionist = mysqli_prepare($conn, $sql_receptionist);
        mysqli_stmt_bind_param($stmt_receptionist, "ss", $receptionist_name, $contact_info);
        
        if (mysqli_stmt_execute($stmt_receptionist)) {
            // Get the last inserted receptionist ID
            $receptionist_id = mysqli_insert_id($conn);

            // Insert into credentials table
            $sql_credentials = "INSERT INTO credentials (Username, Password, Role, Receptionist_ID) VALUES (?, ?, 'Receptionist', ?)";
            $stmt_credentials = mysqli_prepare($conn, $sql_credentials);
            mysqli_stmt_bind_param($stmt_credentials, "ssi", $username, $hashed_password, $receptionist_id);
            
            if (mysqli_stmt_execute($stmt_credentials)) {
                $success = "Receptionist and login credentials added successfully.";
            } else {
                $error = "Error adding credentials: " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt_credentials);
        } else {
            $error = "Error adding receptionist: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt_receptionist);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Receptionist - ABC Virtual Hospital</title>
</head>
<style>
        body {
            background-image: url('../img/img17.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            

        }
</style> 
<body>
    <h1>Add Receptionist</h1>
    
    <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    <?php if (isset($success)) { echo "<p style='color: green;'>$success</p>"; } ?>
    
    <form method="post" action="register_receptionist.php">
        <label for="receptionist_name">Receptionist Name:</label>
        <input type="text" name="receptionist_name" required><br><br>

        <label for="contact_info">Contact Info:</label>
        <input type="text" name="contact_info" required><br><br>

        <label for="username">Username:</label>
        <input type="text" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br><br>

        <input type="submit" name="add_receptionist" value="Add Receptionist">
    </form>
</body>
</html>
