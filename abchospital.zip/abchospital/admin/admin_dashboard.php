<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Retrieve Admin Name and Email from session if they exist
$admin_name = isset($_SESSION['Admin_Name']) ? $_SESSION['Admin_Name'] : "N/A";
$admin_email = isset($_SESSION['Admin_Email']) ? $_SESSION['Admin_Email'] : "N/A";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ABC Virtual Hospital</title>

    <style>
        body {
            background-image: url('../img/img14.jpg');
            background-size: cover;
            background-repeat:no-repeat;
            background-attachment: fixed;

        }
    </style>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($admin_name); ?></h1>
    <p>Your Email: <?php echo htmlspecialchars($admin_email); ?></p>

    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="register_doctor.php">Add Doctor</a></li>
        <li><a href="register_receptionist.php">Add Receptionist</a></li>
    <li><a href="manage_doctors.php">Manage Doctors</a></li>
        <li><a href="manage_patients.php">Manage Patients</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>

    <h3>Dashboard Overview</h3>
    <p>Welcome to the Admin Dashboard. From here, you can manage doctors, patients, and view various hospital reports.</p>
</body>
</html>

