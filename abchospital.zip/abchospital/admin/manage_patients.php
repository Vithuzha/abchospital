<?php
session_start();

// Include the database connection
include('../includes/db_connect.php');

// Check if user is an admin
if ($_SESSION['role'] != 'Admin') {
    echo "Access denied.";
    exit();
}

// Fetch all patients from the database
$sql = "SELECT * FROM patient";
$result = $conn->query($sql);

// Delete patient functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql_delete = "DELETE FROM patient WHERE Patient_ID = $delete_id";
    if ($conn->query($sql_delete) === TRUE) {
        echo "Patient deleted successfully.";
    } else {
        echo "Error deleting patient: " . $conn->error;
    }
    header("Location: manage_patients.php");
}

// Add new patient functionality
if (isset($_POST['add_patient'])) {
    $patient_name = $_POST['patient_name'];
    $contact_info = $_POST['contact_info'];
    $patient_email = $_POST['patient_email'];

    $sql_add = "INSERT INTO patient (Patient_Name, Contact_Info, Patient_Email) VALUES ('$patient_name', '$contact_info', '$patient_email')";
    if ($conn->query($sql_add) === TRUE) {
        echo "New patient added successfully.";
    } else {
        echo "Error adding patient: " . $conn->error;
    }
    header("Location: manage_patients.php");
}

// Update patient functionality
if (isset($_POST['update_patient'])) {
    $patient_id = $_POST['patient_id'];
    $patient_name = $_POST['patient_name'];
    $contact_info = $_POST['contact_info'];
    $patient_email = $_POST['patient_email'];

    $sql_update = "UPDATE patient SET Patient_Name = '$patient_name', Contact_Info = '$contact_info', Patient_Email = '$patient_email' WHERE Patient_ID = $patient_id";
    if ($conn->query($sql_update) === TRUE) {
        echo "Patient updated successfully.";
    } else {
        echo "Error updating patient: " . $conn->error;
    }
    header("Location: manage_patients.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients</title>

    <style>
        body {
            background-image: url('../img/img9.jpg');
            background-size: cover;
            background-repeat:no-repeat;
            background-attachment: fixed;

        }
    </style>

</head>
<body>

<h1>Manage Patients</h1>

<!-- Add Patient Form -->

<table border="1">
    <tr>
        <th>Patient ID</th>
        <th>Patient Name</th>
        <th>Contact Info</th>
        <th>Patient Email</th>
        <th>Actions</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["Patient_ID"] . "</td>
                    <td>" . $row["Patient_Name"] . "</td>
                    <td>" . $row["Contact_Info"] . "</td>
                    <td>" . $row["Patient_Email"] . "</td>
                    <td>
                        <a href='manage_patients.php?edit_id=" . $row["Patient_ID"] . "'>Edit</a> |
                        <a href='manage_patients.php?delete_id=" . $row["Patient_ID"] . "'>Delete</a>
                    </td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No patients found</td></tr>";
    }
    ?>
</table>

<!-- Edit Patient Form (if edit_id is set) -->
<?php
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    $sql_edit = "SELECT * FROM patient WHERE Patient_ID = $edit_id";
    $result_edit = $conn->query($sql_edit);
    $row_edit = $result_edit->fetch_assoc();
    ?>
    <h2>Edit Patient</h2>
    <form method="POST" action="manage_patients.php">
        <input type="hidden" name="patient_id" value="<?php echo $row_edit['Patient_ID']; ?>">
        <input type="text" name="patient_name" value="<?php echo $row_edit['Patient_Name']; ?>" required><br>
        <input type="text" name="contact_info" value="<?php echo $row_edit['Contact_Info']; ?>" required><br>
        <input type="email" name="patient_email" value="<?php echo $row_edit['Patient_Email']; ?>" required><br>
        <input type="submit" name="update_patient" value="Update Patient">
    </form>
    <?php
}
?>

</body>
</html>
