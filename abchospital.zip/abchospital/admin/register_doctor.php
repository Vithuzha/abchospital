<?php
// Include database connection file
include '../includes/db_connect.php';

// Initialize variables for storing form data and messages
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $doctor_name = $_POST['doctor_name'];
    $specialty = $_POST['specialty'];
    $contact_info = $_POST['contact_info'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password for security

    // Insert data into doctor table
    $insert_doctor_query = "INSERT INTO doctor (Doctor_Name, Specialty, Contact_Info) VALUES ('$doctor_name', '$specialty', '$contact_info')";
    
    if (mysqli_query($conn, $insert_doctor_query)) {
        // Get the last inserted Doctor_ID
        $doctor_id = mysqli_insert_id($conn);

        // Insert data into credentials table
        $insert_credentials_query = "INSERT INTO credentials (Username, Password, Role, Doctor_ID) VALUES ('$username', '$hashed_password', 'Doctor', '$doctor_id')";

        if (mysqli_query($conn, $insert_credentials_query)) {
            $message = "Doctor registered successfully!";
        } else {
            $message = "Error creating credentials: " . mysqli_error($conn);
        }
    } else {
        $message = "Error registering doctor: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Doctor</title>
</head>
<style>
        body {
            background-image: url('../img/img16.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            

        }
</style> 
<body>
    <h2>Register New Doctor</h2>
    
    <?php if ($message) echo "<p>$message</p>"; ?>

    <form action="register_doctor.php" method="post">
        <label for="doctor_name">Doctor Name:</label>
        <input type="text" name="doctor_name" id="doctor_name" required><br><br>

        <label for="specialty">Specialty:</label>
        <input type="text" name="specialty" id="specialty"><br><br>

        <label for="contact_info">Contact Info:</label>
        <input type="text" name="contact_info" id="contact_info"><br><br>

        <h3>Login Credentials</h3>
        
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br><br>

        <input type="submit" value="Register Doctor">
    </form>
</body>
</html>
