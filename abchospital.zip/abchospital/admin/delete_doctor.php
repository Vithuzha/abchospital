<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Handle deletion
if (isset($_GET['doctor_id'])) {
    $doctor_id = intval($_GET['doctor_id']); // Ensure the ID is an integer

    // Begin transaction for safety
    mysqli_begin_transaction($conn);

    try {
        // Delete from credentials table
        $sql_credentials = "DELETE FROM credentials WHERE Doctor_ID = ?";
        $stmt = mysqli_prepare($conn, $sql_credentials);
        mysqli_stmt_bind_param($stmt, "i", $doctor_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Delete from doctor table
        $sql_doctor = "DELETE FROM doctor WHERE Doctor_ID = ?";
        $stmt = mysqli_prepare($conn, $sql_doctor);
        mysqli_stmt_bind_param($stmt, "i", $doctor_id);
        mysqli_stmt_execute($stmt);

        // Commit the transaction
        mysqli_commit($conn);

        $success = "Doctor deleted successfully.";
    } catch (Exception $e) {
        // Rollback on error
        mysqli_rollback($conn);
        $error = "Error deleting doctor: " . $e->getMessage();
    }
}

// Fetch all doctors for display
$sql = "SELECT Doctor_ID, Doctor_Name, Specialty, Contact_Info FROM doctor";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Doctor - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <div class="container">
        <h1>Delete Doctor</h1>

        <?php if (isset($success)) { echo "<p class='success'>$success</p>"; } ?>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Specialty</th>
                    <th>Contact Info</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['Doctor_ID']); ?></td>
                        <td><?php echo htmlspecialchars($row['Doctor_Name']); ?></td>
                        <td><?php echo htmlspecialchars($row['Specialty']); ?></td>
                        <td><?php echo htmlspecialchars($row['Contact_Info']); ?></td>
                        <td>
                            <a href="delete_doctor.php?doctor_id=<?php echo $row['Doctor_ID']; ?>"
                               onclick="return confirm('Are you sure you want to delete this doctor?');">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <p><a href="../auth/admin_dashboard.php">Back to Admin Dashboard</a></p>
    </div>
</body>
</html>
