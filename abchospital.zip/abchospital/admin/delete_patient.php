<?php
session_start();
include('../includes/db_connect.php');

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Check if the patient ID is passed in the query string
if (isset($_GET['id'])) {
    $patient_id = $_GET['id'];

    // Fetch patient data for confirmation
    $sql = "SELECT * FROM patient WHERE Patient_ID = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $patient_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $patient = mysqli_fetch_assoc($result);

    // If no patient is found
    if (!$patient) {
        $error = "Patient not found!";
    }

    // Handle deletion request
    if (isset($_POST['delete'])) {
        // Prepare and execute the delete query
        $sql_delete = "DELETE FROM patient WHERE Patient_ID = ?";
        $stmt_delete = mysqli_prepare($conn, $sql_delete);
        mysqli_stmt_bind_param($stmt_delete, "i", $patient_id);

        if (mysqli_stmt_execute($stmt_delete)) {
            header("Location: manage_patients.php?success=Patient deleted successfully");
            exit();
        } else {
            $error = "Error deleting patient: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: manage_patients.php?error=No patient ID provided");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Patient - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Delete Patient</h1>
        
        <?php if (isset($error)) { echo "<div class='error'>$error</div>"; } ?>
        
        <?php if (isset($patient)): ?>
            <p>Are you sure you want to delete the following patient?</p>
            <table>
                <tr>
                    <td><strong>Name:</strong></td>
                    <td><?php echo htmlspecialchars($patient['Patient_Name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Age:</strong></td>
                    <td><?php echo htmlspecialchars($patient['Age']); ?></td>
                </tr>
                <tr>
                    <td><strong>Contact Info:</strong></td>
                    <td><?php echo htmlspecialchars($patient['Contact_Info']); ?></td>
                </tr>
            </table>
            <form method="POST" action="">
                <button type="submit" name="delete">Delete Patient</button>
                <a href="manage_patients.php" class="cancel-btn">Cancel</a>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
