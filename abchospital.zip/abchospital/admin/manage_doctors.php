<?php
session_start();
include('../includes/db_connect.php');

// Check if the admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch all doctors from the database
$sql_fetch_doctors = "SELECT * FROM doctor";
$stmt_fetch = $conn->prepare($sql_fetch_doctors);
$stmt_fetch->execute();
$result_doctors = $stmt_fetch->get_result();

// Check if the form is submitted for adding a new doctor
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_doctor'])) {
    $doctor_name = htmlspecialchars($_POST['doctor_name'], ENT_QUOTES, 'UTF-8');
    $specialty = htmlspecialchars($_POST['specialty'], ENT_QUOTES, 'UTF-8');
    $contact_info = htmlspecialchars($_POST['contact_info'], ENT_QUOTES, 'UTF-8');

    // Insert the new doctor into the database
    $sql_insert_doctor = "INSERT INTO doctor (Doctor_Name, Specialty, Contact_Info) VALUES (?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert_doctor);
    $stmt_insert->bind_param("sss", $doctor_name, $specialty, $contact_info);

    if ($stmt_insert->execute()) {
        echo "Doctor added successfully!";
        header("Location: manage_doctors.php");
        exit();
    } else {
        echo "Error: " . $stmt_insert->error;
    }
}

// Check if the form is submitted for updating doctor details
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_doctor'])) {
    $doctor_id = intval($_POST['doctor_id']);
    $doctor_name = htmlspecialchars($_POST['doctor_name'], ENT_QUOTES, 'UTF-8');
    $specialty = htmlspecialchars($_POST['specialty'], ENT_QUOTES, 'UTF-8');
    $contact_info = htmlspecialchars($_POST['contact_info'], ENT_QUOTES, 'UTF-8');

    // Update the doctor's details in the database
    $sql_update_doctor = "UPDATE doctor SET Doctor_Name = ?, Specialty = ?, Contact_Info = ? WHERE Doctor_ID = ?";
    $stmt_update = $conn->prepare($sql_update_doctor);
    $stmt_update->bind_param("sssi", $doctor_name, $specialty, $contact_info, $doctor_id);

    if ($stmt_update->execute()) {
        echo "Doctor details updated successfully!";
        header("Location: manage_doctors.php");
        exit();
    } else {
        echo "Error: " . $stmt_update->error;
    }
}

// Check if the form is submitted for deleting a doctor
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_doctor'])) {
    $doctor_id = intval($_POST['doctor_id']);

    // Delete the doctor from the database
    $sql_delete_doctor = "DELETE FROM doctor WHERE Doctor_ID = ?";
    $stmt_delete = $conn->prepare($sql_delete_doctor);
    $stmt_delete->bind_param("i", $doctor_id);

    if ($stmt_delete->execute()) {
        echo "Doctor deleted successfully!";
        header("Location: manage_doctors.php");
        exit();
    } else {
        echo "Error: " . $stmt_delete->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors - ABC Virtual Hospital</title>

    <style>
        body {
            background-image: url('../img/img13.jpg');
            background-size: cover;
            background-repeat:no-repeat;
            background-attachment: fixed;

        }
    </style>
</head>
<body>
    <h1>Manage Doctors</h1>


    <?php if ($result_doctors->num_rows > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Doctor ID</th>
                    <th>Doctor Name</th>
                    <th>Specialty</th>
                    <th>Contact Info</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($doctor = $result_doctors->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($doctor['Doctor_ID']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['Doctor_Name']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['Specialty']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['Contact_Info']); ?></td>
                        <td>
                            <!-- Edit Doctor Form -->
                            <form method="post" action="" style="display:inline;">
                                <input type="hidden" name="doctor_id" value="<?php echo htmlspecialchars($doctor['Doctor_ID']); ?>">
                                <input type="text" name="doctor_name" value="<?php echo htmlspecialchars($doctor['Doctor_Name']); ?>" required>
                                <input type="text" name="specialty" value="<?php echo htmlspecialchars($doctor['Specialty']); ?>" required>
                                <input type="text" name="contact_info" value="<?php echo htmlspecialchars($doctor['Contact_Info']); ?>" required>
                                <input type="submit" name="update_doctor" value="Update">
                            </form>
                            <!-- Delete Doctor Form -->
                            <form method="post" action="" style="display:inline;">
                                <input type="hidden" name="doctor_id" value="<?php echo htmlspecialchars($doctor['Doctor_ID']); ?>">
                                <input type="submit" name="delete_doctor" value="Delete" onclick="return confirm('Are you sure you want to delete this doctor?');">
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No doctors found.</p>
    <?php endif; ?>

    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
