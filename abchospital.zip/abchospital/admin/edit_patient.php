<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is authorized (e.g., Admin)
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Get the patient ID from the URL
if (!isset($_GET['id'])) {
    header("Location: manage_patients.php?error=Patient ID is required");
    exit();
}
$patient_id = $_GET['id'];

// Fetch the patient's current data
$sql = "SELECT * FROM patient WHERE Patient_ID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $patient_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$patient_data = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$patient_data) {
    header("Location: manage_patients.php?error=Patient not found");
    exit();
}

// Handle form submission for updating the patient
if (isset($_POST['update'])) {
    $patient_name = $_POST['patient_name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $contact_info = $_POST['contact_info'];
    $address = $_POST['address'];
    $medical_history = $_POST['medical_history'];

    // Update the patient in the database
    $sql_update = "UPDATE patient SET 
        Patient_Name = ?, 
        Age = ?, 
        Gender = ?, 
        Contact_Info = ?, 
        Address = ?, 
        Medical_History = ?
        WHERE Patient_ID = ?";
    $stmt_update = mysqli_prepare($conn, $sql_update);
    mysqli_stmt_bind_param($stmt_update, "sissssi", $patient_name, $age, $gender, $contact_info, $address, $medical_history, $patient_id);

    if (mysqli_stmt_execute($stmt_update)) {
        mysqli_stmt_close($stmt_update);
        header("Location: manage_patients.php?success=Patient updated successfully");
        exit();
    } else {
        $error = "Error updating patient: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Patient</h1>

        <!-- Error Message -->
        <?php if (isset($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <!-- Patient Edit Form -->
        <form method="post" action="">
            <label for="patient_name">Patient Name:</label>
            <input type="text" name="patient_name" id="patient_name" value="<?php echo htmlspecialchars($patient_data['Patient_Name']); ?>" required><br>

            <label for="age">Age:</label>
            <input type="number" name="age" id="age" value="<?php echo htmlspecialchars($patient_data['Age']); ?>" required><br>

            <label for="gender">Gender:</label>
            <select name="gender" id="gender" required>
                <option value="Male" <?php if ($patient_data['Gender'] == 'Male') echo 'selected'; ?>>Male</option>
                <option value="Female" <?php if ($patient_data['Gender'] == 'Female') echo 'selected'; ?>>Female</option>
                <option value="Other" <?php if ($patient_data['Gender'] == 'Other') echo 'selected'; ?>>Other</option>
            </select><br>

            <label for="contact_info">Contact Info:</label>
            <input type="text" name="contact_info" id="contact_info" value="<?php echo htmlspecialchars($patient_data['Contact_Info']); ?>" required><br>

            <label for="address">Address:</label>
            <textarea name="address" id="address" required><?php echo htmlspecialchars($patient_data['Address']); ?></textarea><br>

            <label for="medical_history">Medical History:</label>
            <textarea name="medical_history" id="medical_history"><?php echo htmlspecialchars($patient_data['Medical_History']); ?></textarea><br>

            <input type="submit" name="update" value="Update Patient">
        </form>

        <br>
        <a href="manage_patients.php" class="btn btn-back">Back to Manage Patients</a>
    </div>
</body>
</html>
