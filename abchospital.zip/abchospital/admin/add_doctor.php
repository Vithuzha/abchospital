<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate inputs
    $doctor_name = mysqli_real_escape_string($conn, $_POST['doctor_name']);
    $specialty = mysqli_real_escape_string($conn, $_POST['specialty']);
    $contact_info = mysqli_real_escape_string($conn, $_POST['contact_info']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $admin_id = $_SESSION['user_id']; // Admin ID from session

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if the username already exists
    $check_user_query = "SELECT * FROM credentials WHERE username = ?";
    $stmt = mysqli_prepare($conn, $check_user_query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $error = "Username already exists. Please choose a different username.";
    } else {
        // Insert the doctor into the Doctor table
        $sql_doctor = "INSERT INTO doctor (Doctor_Name, Specialty, Contact_Info, Admin_ID) 
                       VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql_doctor);
        mysqli_stmt_bind_param($stmt, "sssi", $doctor_name, $specialty, $contact_info, $admin_id);

        if (mysqli_stmt_execute($stmt)) {
            $doctor_id = mysqli_insert_id($conn); // Get the inserted doctor ID

            // Insert credentials for the doctor
            $sql_credentials = "INSERT INTO credentials (Username, Password, Role, Doctor_ID) 
                                 VALUES (?, ?, 'Doctor', ?)";
            $stmt = mysqli_prepare($conn, $sql_credentials);
            mysqli_stmt_bind_param($stmt, "ssi", $username, $hashed_password, $doctor_id);

            if (mysqli_stmt_execute($stmt)) {
                $success = "Doctor registered successfully!";
            } else {
                $error = "Error registering credentials: " . mysqli_error($conn);
            }
        } else {
            $error = "Error registering doctor: " . mysqli_error($conn);
        }
    }

    // Close statement
    mysqli_stmt_close($stmt);
}

// Close connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Doctor - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css">
    
</head>
<body>
    <div class="container">
        <h1>Add Doctor</h1>

        <?php if (isset($success)) { echo "<p class='success'>$success</p>"; } ?>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <form method="post" action="add_doctor.php">
            <label for="doctor_name">Doctor Name:</label>
            <input type="text" id="doctor_name" name="doctor_name" required>

            <label for="specialty">Specialty:</label>
            <input type="text" id="specialty" name="specialty">

            <label for="contact_info">Contact Info:</label>
            <input type="text" id="contact_info" name="contact_info" required>

            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Register Doctor">
        </form>

        <p><a href="../auth/admin_dashboard.php">Back to Admin Dashboard</a></p>
    </div>
</body>
</html>
