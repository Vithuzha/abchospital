<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch the doctor's details for editing
if (isset($_GET['doctor_id'])) {
    $doctor_id = intval($_GET['doctor_id']); // Ensure ID is an integer

    $sql = "SELECT * FROM doctor WHERE Doctor_ID = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $doctor_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $doctor_data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$doctor_data) {
        die("Doctor not found.");
    }
} else {
    die("Doctor ID not provided.");
}

// Handle form submission for updating doctor details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor_name = $_POST['doctor_name'];
    $specialty = $_POST['specialty'];
    $contact_info = $_POST['contact_info'];

    $sql_update = "UPDATE doctor SET Doctor_Name = ?, Specialty = ?, Contact_Info = ? WHERE Doctor_ID = ?";
    $stmt = mysqli_prepare($conn, $sql_update);
    mysqli_stmt_bind_param($stmt, "sssi", $doctor_name, $specialty, $contact_info, $doctor_id);

    if (mysqli_stmt_execute($stmt)) {
        $success = "Doctor details updated successfully.";
        header("Location: manage_doctors.php?success=" . urlencode($success));
        exit();
    } else {
        $error = "Error updating doctor details: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Doctor - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Doctor</h1>

        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

        <form method="post" action="edit_doctor.php?doctor_id=<?php echo $doctor_id; ?>">
            <label for="doctor_name">Doctor Name:</label>
            <input type="text" name="doctor_name" id="doctor_name" value="<?php echo htmlspecialchars($doctor_data['Doctor_Name']); ?>" required><br>

            <label for="specialty">Specialty:</label>
            <input type="text" name="specialty" id="specialty" value="<?php echo htmlspecialchars($doctor_data['Specialty']); ?>"><br>

            <label for="contact_info">Contact Info:</label>
            <input type="text" name="contact_info" id="contact_info" value="<?php echo htmlspecialchars($doctor_data['Contact_Info']); ?>"><br>

            <button type="submit">Update Doctor</button>
        </form>

        <p><a href="manage_doctors.php">Back to Manage Doctors</a></p>
    </div>
</body>
</html>
