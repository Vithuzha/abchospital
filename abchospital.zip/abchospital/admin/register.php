<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
// if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
//     header("Location: ../auth/login.php");
//     exit();
// }

if (isset($_POST['register'])) {
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashing the password

    // Insert the new admin into the database
    $sql_admin = "INSERT INTO admin (Admin_Name, Admin_Email) VALUES ('$admin_name', '$admin_email')";

    if (mysqli_query($conn, $sql_admin)) {
        // Get the ID of the newly inserted admin
        $new_admin_id = mysqli_insert_id($conn);

        // Now insert the credentials for the admin
        $sql_credentials = "INSERT INTO credentials (Username, Password, Role, Admin_ID)
                            VALUES ('$username', '$password', 'Admin', $new_admin_id)";

        if (mysqli_query($conn, $sql_credentials)) {
            $success = "Admin and credentials registered successfully!";
        } else {
            $error = "Error registering credentials: " . mysqli_error($conn);
        }
    } else {
        $error = "Error registering admin: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin - ABC Virtual Hospital</title>
</head>
<body>
    <h1>Register Admin</h1>
    
    <?php if (isset($success)) { echo "<p>$success</p>"; } ?>
    <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>

    <form method="post" action="register.php">
        <label for="admin_name">Admin Name:</label>
        <input type="text" name="admin_name" required><br>

        <label for="admin_email">Admin Email:</label>
        <input type="email" name="admin_email" required><br>

        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="register" value="Register Admin">
    </form>

    <br>
    <a href="../admin/admin_dashboard.php">Back to Admin Dashboard</a>
</body>
</html>
