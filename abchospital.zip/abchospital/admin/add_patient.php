<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $age = intval($_POST['age']);
    $gender = $_POST['gender'];
    $contact_info = $_POST['contact_info'];

    // Insert patient into the database
    $sql = "INSERT INTO patient (Full_Name, Age, Gender, Contact_Info) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "siss", $full_name, $age, $gender, $contact_info);

    if (mysqli_stmt_execute($stmt)) {
        $success = "Patient added successfully.";
        header("Location: manage_patients.php?success=" . urlencode($success));
        exit();
    } else {
        $error = "Error adding patient: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Patient - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Patient</h1>

        <!-- Success/Error Messages -->
        <?php if (isset($error)) { echo "<p class='error'>" . htmlspecialchars($error) . "</p>"; } ?>

        <!-- Add Patient Form -->
        <form method="post" action="add_patient.php">
            <label for="full_name">Full Name:</label>
            <input type="text" name="full_name" id="full_name" required><br>

            <label for="age">Age:</label>
            <input type="number" name="age" id="age" min="0" required><br>

            <label for="gender">Gender:</label>
            <select name="gender" id="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select><br>

            <label for="contact_info">Contact Info:</label>
            <input type="text" name="contact_info" id="contact_info" required><br>

            <input type="submit" value="Add Patient">
        </form>

        <br>
        <a href="manage_patients.php" class="button">Back to Manage Patients</a>
    </div>
</body>
</html>
