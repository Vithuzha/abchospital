<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = "1"; // Replace with your database password
$dbname = "abc_hospital"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_name = mysqli_real_escape_string($conn, $_POST['patient_name']);
    $contact_info = mysqli_real_escape_string($conn, $_POST['contact_info']);
    $patient_email = mysqli_real_escape_string($conn, $_POST['patient_email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Encrypt password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // SQL query to insert patient data
    $sql = "INSERT INTO patient (Patient_Name, Contact_Info, Patient_Email) 
            VALUES ('$patient_name', '$contact_info', '$patient_email')";

    if ($conn->query($sql) === TRUE) {
        // If patient data is inserted successfully, create an account in credentials table
        $patient_id = $conn->insert_id;  // Get the Patient_ID of the newly inserted record
        $role = "Patient";  // Set role as Patient

        $sql_credentials = "INSERT INTO credentials (Username, Password, Role, Patient_ID)
                            VALUES ('$patient_email', '$hashed_password', '$role', '$patient_id')";

        if ($conn->query($sql_credentials) === TRUE) {
            echo "Registration successful! You can now log in.";
        } else {
            echo "Error: " . $sql_credentials . "<br>" . $conn->error;
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration</title>
    <link rel="stylesheet" href="styles.css"> <!-- Add your CSS file here -->
</head>
<body>
    <div class="container">
        <h2>Patient Registration Form</h2>
        <form action="register_patient.php" method="POST">
            <label for="patient_name">Full Name:</label>
            <input type="text" id="patient_name" name="patient_name" required>

            <label for="contact_info">Contact Information:</label>
            <input type="text" id="contact_info" name="contact_info">

            <label for="patient_email">Email Address:</label>
            <input type="email" id="patient_email" name="patient_email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
