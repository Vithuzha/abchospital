<?php
session_start();
include('db_connect.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to get user info
    $sql = "SELECT * FROM credentials WHERE Username = '$username'";
    $result = mysqli_query($conn, $sql);
    $user_data = mysqli_fetch_assoc($result);

    // Check if user exists and password matches
    if ($user_data && password_verify($password, $user_data['Password'])) {
        $_SESSION['user_id'] = $user_data['User_ID'];
        $_SESSION['role'] = $user_data['Role'];

        // Redirect based on user role
        switch ($user_data['Role']) {
            case 'Admin':
                $admin_id = $user_data['Admin_ID'];
                $admin_query = "SELECT * FROM admin WHERE Admin_ID = $admin_id";
                $admin_result = mysqli_query($conn, $admin_query);
                $admin_data = mysqli_fetch_assoc($admin_result);
                
                if ($admin_data) {
                    $_SESSION['Admin_Name'] = $admin_data['Admin_Name'];
                    $_SESSION['Admin_Email'] = $admin_data['Admin_Email'];
                }
                header("Location: ../admin/admin_dashboard.php");
                exit();
                
            case 'Doctor':
                // Redirect to doctor dashboard
                header("Location: ../doctors/doctor_dashboard.php");
                exit();
                
            case 'Receptionist':
                // Redirect to receptionist dashboard
                header("Location: ../receptionists/receptionist_dashboard.php");
                exit();
                
            case 'Patient':
                // Redirect to patient dashboard
                header("Location: ../patients/patient_dashboard.php");
                exit();
                
            default:
                $error = "Invalid role.";
                break;
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="../assets/login_style.css">
<link rel="stylesheet" href="../assets/Navigation_Style.css">
    <style>
        .login {
            background-color: rgb(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            border-radius: 1rem; /* Rounded corners */
            padding: 20px;
            text-align: center;
            width: 80%; /* Optional: Control the width */
            max-width: 600px; /* Optional: Set a max-width for responsiveness */
            
        }

        input {
            margin-top: 1cap;
            background-color: aqua;
            padding-left: 1cap;

        }

        button {
            margin: 1cap;

        }
        
        
        body {
        background-image: url("../img/Hospital\ Web\ Desktop\ Prototype.jpg");
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        height: 100vh; /* Full viewport height */
        margin: 0; /* Remove default margin */
        display: flex;
        flex-direction: column; /* Stack elements vertically */
    }

    .header {
        width: 100%;
        position: fixed; /* Fix the navigation bar to the top */
        top: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.7); /* Optional: Make it semi-transparent */
        z-index: 1000; /* Ensure it's above other elements */
    }

    .nav ul {
        list-style: none;
        margin: 0;
        padding: 10px 20px;
        display: flex;
        justify-content: flex-start; /* Align items to the left */
        gap: 15px; /* Space between links */
    }

    .nav ul li a {
        text-decoration: none;
        color: white;
    }

    .cont {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%; /* Take the remaining space */
        flex-grow: 1; /* Allow it to grow and fill the available space */
    }

    section {
        background-color: rgba(0, 0, 0, 0.6); /* Use rgba for transparency */
        backdrop-filter: blur(5px);
        border-radius: 1rem; /* Rounded corners */
        padding: 20px;
        text-align: center;
        width: 80%; /* Optional: Control the width */
        max-width: 600px; /* Optional: Set a max-width for responsiveness */
    }

    h1 {
        color: rgb(234, 234, 234);
    }

    button {
        background-color: green;
        color: bisque;
    }
    </style>
</head>
<body>

<div class="header">
<div class="nav">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../news.html">News</a></li>
                <li><a href="../patients/book_appointment.php">Book Appointment</a></li>


                <!-- <li><a href="#">Gallery</a></li> -->
                <!-- <li><a href="#">Contact Us</a></li> -->
                <li><a href="../about-us.html">About Us</a></li>
            </ul>
            
        </div>
        </div>
        <br><br><br><br>
    <div class="login">

    
    <h1>Login</h1>
    
    <?php if (isset($error)) { echo "<p>$error</p>"; } ?>
    
    <form method="post" action="login.php">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="login" value="Login">
    </form>
    <a href="patient-registration.php"><button>Signup</button></a>
    </div>
</body>
</html>
