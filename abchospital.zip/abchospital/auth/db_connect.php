<?php
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "1"; // Replace with your MySQL password
$dbname = "abc_hospital"; // Replace with your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
