<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABC Virtual Hospital</title>
    <link rel="stylesheet" href="assets/reset.css?version=1 ">
    <link rel="stylesheet" href="assets/login_style.css?version= 1">
    <link rel="stylesheet" href="assets/Navigation_Style.css?version=1" />
    <link rel="stylesheet" href="assets/style.css?version=1">
    <style>
        body {
            background-image: url("img/Hospital\ Web\ Desktop\ Prototype.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            height: 100vh;
            /* Full viewport height */
            margin: 0;
            /* Remove default margin */
            display: flex;
            flex-direction: column;
            /* Stack elements vertically */
        }

        .header {
            width: 100%;
            position: fixed;
            /* Fix the navigation bar to the top */
            top: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.7);
            /* Optional: Make it semi-transparent */
            z-index: 1000;
            /* Ensure it's above other elements */
        }

        .nav ul {
            list-style: none;
            margin: 0;
            padding: 10px 20px;
            display: flex;
            justify-content: flex-start;
            /* Align items to the left */
            gap: 15px;
            /* Space between links */
        }

        .nav ul li a {
            text-decoration: none;
            color: white;
        }

        .cont {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            /* Take the remaining space */
            flex-grow: 1;
            /* Allow it to grow and fill the available space */
        }

        section {
            background-color: rgba(0, 0, 0, 0.6);
            /* Use rgba for transparency */
            backdrop-filter: blur(5px);
            border-radius: 1rem;
            /* Rounded corners */
            padding: 20px;
            text-align: center;
            width: 80%;
            /* Optional: Control the width */
            max-width: 600px;
            /* Optional: Set a max-width for responsiveness */
        }

        h1 {
            color: rgb(234, 234, 234);
        }

        .login-in {
            text-align: end;
            text-decoration: none;
            width: 30px;
            margin-right: 20px;
        }

    </style>


</head>

<body>
    <div class="header">
        <div class="nav">
        
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="news.html">News</a></li>
                <li><a href="patients/book_appointment.php">Book Appointment</a></li>


                <!-- <li><a href="#">Gallery</a></li> -->
                <!-- <li><a href="#">Contact Us</a></li> -->
                <li><a href="about-us.html">About Us</a></li>
            </ul>
            <a href="./auth/login.php"><img class="login-in" src="./img/login.png" alt="login-icon"></a>
      

        </div>
    </div>

    <br>
    <br>
    <br>
    <br>


    <div class="cont">
        <section class=" contant-section">
            <h1>Welcome to ABC Virtual Hospital</h1>

            <nav class="index">
                <p>
                    --Your health, our priority--
                </p>
                <!-- <a href="auth/login.php"><button>Login</button></a> | -->
                <a href="./patients/register.php"><button>Patient Registration</button></a>
            </nav>
        </section>
    </div>
</body>

</html>